# DVI Bridge Basic Package

This package contains the core MQTT bridge for DVI heat pumps.

## Installation
1. Extract to /home/dviha/dvi-bridge/
2. Create virtual environment and install requirements
3. Configure .env file with MQTT settings
4. Set up systemd service

See main repository for detailed instructions.
