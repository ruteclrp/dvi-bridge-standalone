# DVI Sidecar Web Interface Package

This package contains the standalone web interface for DVI heat pumps.
Requires the bridge basic package to be installed first.

## Installation
1. Extract to /home/dviha/dvi-bridge/
2. Install requirements from sidecar/requirements.txt
3. Set up systemd service for webbridge
4. Access web interface at http://[rpi-ip]:5555

See main repository for detailed instructions.
